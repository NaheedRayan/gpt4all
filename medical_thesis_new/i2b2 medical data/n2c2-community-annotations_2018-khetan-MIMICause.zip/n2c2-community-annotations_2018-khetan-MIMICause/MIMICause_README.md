The content of this folder and their details is provided below:

1) MIMICause_Annotations.csv - The MIMICause dataset having 4 columns and 2714 rows. The column name and their descriptions are provided as follows:

    a) E1 - Entity 1 which is enclosed between the tags <e1> and </e1> in the sentence.
    b) E2 - Entity 2 which is enclosed between the tags <e2> and </e2> in the sentence.
    c) Text - The clinical note text snippet containing the entities E1, E2 and the context in which the causal relationship between them is annotated.
    d) Label - One of the 9 causal annotations (with directionality) assigned to the clinical note text snippet.

    The entity numbering can be arbitrary and is not based on the order of occurrence. An example row entry taken from the dataset is provided below:

    myopathy,steroid,Steroid Myopathy: Patient had a history of <e2>steroid</e2> induced <e1>myopathy</e1> and had presented with an ongoing steroid taper.,"Cause(E2,E1)"

    In this example, the myopathy is entity 1 i.e. E1, the steroid is entity 2 i.e. E2 and in the context of the entity tagged clinical note text snippet provided, the causal relationship is Cause(E2,E1) i.e. steroid caused the myopathy.

2) MIMICause_Annotation-Guidelines.pdf - The document providing the overview, annotation guidelines and the final count of the examples of each causal relation type (with direction) in the MIMICause dataset.

3) MIMICause_Inter-Annotator-Agreement.txt - The document mentioning the inter-annotator agreement (IAA) Fleiss' kappa score, the details regarding number of annotators and the annotation disagreement resolution strategy.
