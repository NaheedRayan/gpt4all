DrugEHRQA is the first question answering (QA) dataset containing question-answers from both structured tables and discharge summaries of MIMIC-III.
It contains medicine-related queries on patient records. We are submitting 41702 pairs of question and answers, retrieved from the unstructured notes of MIMIC-III here (n2c2 repository). Our QA dataset on the structured tables of MIMIC-III can be accessed through Physionet (https://physionet.org/). Both these datasets are combined to generate a multimodal QA dataset (DrugEHRQA). We had to submit it in different platforms for licence issues. Our goal is to provide a benchmark dataset for multi-modal QA systems, and to open up new avenues of research  in improving question answering over structured EHR data  by using context context from clinical notes.
We used the annotations from - '2018 (Track 2) ADE and Medication Extraction Challenge' to generate/annotate thsi QA dataset.

Files included:
1./annotations 
    It contains 9 xlsx files, Each of the files contain a different template of questions, along with its paraphrases.
    The files have two fields: NL_Questions and Answer_Unstructured.
    It contains medicine-related queries like - dosage, form, route and reason for taking drug.

2./Annotation Guidelines.pdf
Describes the annotation procedure and guidelines.

Note: This dataset is submitted as part of 'NeurIPS 2021 Track Datasets and Benchmarks Round 2'. The paper will be updated here, after it is accepted by NeurIPS. The code to combine the structured QA dataset and unstructured QA dataset for generating the multimodal QA dataset, will be shared after the acceptance of the paper in NeurIPS. Also, since we have used an automated method to generate the dataset, so there was no need to include any 'Inter annotator agreement'.
